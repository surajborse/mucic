module.exports = {

    Music: [


        {

            Image: "http://www.shockya.com/news/wp-content/uploads/Bazodee-Poster.jpe",
            title: "nazar naa lagaa jae  ",
            subtitle: " Riwan khan ",
            audio: "https://2022.dming2022.xyz/bollywood%20mp3/Shershaah%20(2021)/01%20-%20Raataan%20Lambiyan%20(128%20Kbps).mp3"
        },


        {
          
            Image: "https://mumbaidjs.org/siteuploads/thumb/sft32/15647_2.jpg",
            title: "O Sheth Tumhi Nadach Kelay Thet",
            subtitle: "Ajay Gogavale ",
            audio: "https://mumbaidjs.org/files/download/id/15647&volume=75&showstop=1&showvolume=1"



        },


        {
        
            Image: "https://i.pinimg.com/736x/b0/67/56/b067565825bce9cc94fe187320d5d16d.jpg",
            title: "Aate Di Chidi Title Song",
            subtitle: " Deep Kandiara , Kaptaan , Amrit Maan ,",
            audio: "https://p128.ve.vc/data/48/43777/289512/Aate%20Di%20Chidi%20Title%20Song%20-%20Mankirat%20Pannu.mp3"

        },


        {
         
            Image: "https://c.saavncdn.com/634/Kanudo-Kamangaro-Gujarati-2020-20201212233049-500x500.jpg",
            title: "Kanudo Chhe Kamangaro Hemant ",
            subtitle: " Hemant Chauhan - Vol. 5",
            audio: "https://dns4.vippendu.com/download/128k-xmak/Kanudo-Chhe-Kamangaro.mp3"

        },

        {
          
            Image: "https://www.behindwoods.com/hindi-movies/ms-dhoni-the-untold-story/images/thumbnails/ms-dhoni-the-untold-story-songs-review.jpg",
            title: " Besabriyaan - M.S. Dhoni - ",
            subtitle: "℗Sushant Singh Rajput, Herry Tangri,  ",
            audio: "https://pagalsong.in/uploads/systemuploads/mp3/M.S.%20Dhoni%20-%20The%20Untold%20Story/Besabriyaan%20(M%20S%20Dhoni%20-%20The%20Untold%20Story)%20128.mp3"

        },

        {
           
            Image: "https://i2.cinestaan.com/image-bank/1500-1500/179001-180000/179501.jpg",
            title: "Darlink",
            subtitle: "Jaundya Na Balasaheb (2016)",
            audio: "https://djstation.in/upload_file/41/148/570/Mona%20Darling-(djsstation.com).mp3"

        },

        {
           
            Image: "https://i.pinimg.com/236x/9f/b1/19/9fb119998351265b47f8b33706430da9--romantic-movies-bollywood-stars.jpg",
            title: "Badtameez Dil",
            subtitle: "Ranbir Kapoor, Deepika Padukone,",
            audio: "https://pagalfree.com/musics/128-Badtameez%20Dil%20-%20Yeh%20Jawaani%20Hai%20Deewani%20128%20Kbps.mp3"

        },

        {
          
            Image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRFeNmr-tETTMg32PUpZ--vHuyz-9wSzjUdsg&usqp=CAU",
            title: "Breaking the Rules",
            subtitle: "Jubin Nautiyal",
            category: "english",
            audio: "https://pagalnew.com/mp3-songs/english-mp3-songs/breaking-the-rules-jubin-nautiyal-128-kbps-sound.mp3"

        },

        {
        
            Image: "https://m.media-amazon.com/images/I/91SvpmEQirL._SS500_.jpg",
            title: " Covid Yoddha Mhana",
            subtitle: " - Dj Ajay Asr.mp3",
            audio: "https://djking.co.in/files/download/63763.html"

        },

        {
            
            Image: "https://m.media-amazon.com/images/I/81JZRejRNWL._SL1500_.jpg",
            title: "Yeh Jawaani Hai Deewani",
            subtitle: "Vishal Dadlani, Shalmali Kholgade",
            audio: "https://pagalfree.com/musics/128-Balam%20Pichkari%20-%20Yeh%20Jawaani%20Hai%20Deewani%20128%20Kbps.mp3"

        },



        {
           
            Image: "https://images-na.ssl-images-amazon.com/images/I/71EnAsiGPNL._RI_.jpg",
            title: "Bahu Nachi Kilki Pati",
            subtitle: "U.K. Haryanvi, Gulshan Music",
            category: "tamil",
            audio: "https://pagalfree.com/musics/128-Bahu%20Nachi%20Kilki%20Pati%20-%20U.K.%20Haryanvi%20128%20Kbps.mp3"

        },

        {
          
            Image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSxrfmQKA6qab6WawDlxPjEwoh2fflJHoSLTA&usqp=CAU",
            title: "Unchi Haveli ",
            subtitle: "Renuka Panwar, Aditya Kalkal ",
            audio: "https://mymp3bhojpuri.in/files/download/id/24509"

        },

        {
           
            Image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQR4S4VfXBZmpVlEAW_Y-sIft0qjni9jB6kFTlhO0H19dRNtuQYiaLTzPuzkRiVzkleU5M&usqp=CAU",
            title: "Taka Tak",
            subtitle: "marathi mr,ajay ",
            audio: "https://hindimp3song.in/files/download/id/1412&volume=75&showstop=1&showvolume=1"

        },

        {
         
            Image: "https://static.toiimg.com/thumb/msid-61262343,width-219,height-317,imgsize-54623/61262343.jpg",
            title: "You - Benny Blanco ",
            subtitle: "Benny Blanco, Marshmello,",
            category: "english",
            audio: "https://pagalnew.com/mp3-songs/english-mp3-songs/you-benny-blanco-128-kbps-sound.mp3"

        },

        {
           
            Image: "https://i.ytimg.com/vi/o5e7ywA1dFI/hqdefault.jpg",
            title: "Nobody Is Listening",
            subtitle: "Zayn Malik",
            category: "english",
            audio: "https://pagalnew.com/mp3-songs/english-mp3-songs/better-nobody-is-listening-128-kbps-sound.mp3"

        },

        {
            Image: "https://stat1.bollywoodhungama.in/wp-content/uploads/2017/08/Boyz-e1503728249714.jpg",
            title: "Goti Soda Batli Foda ",
            subtitle: " Adarsh Shinde,Rohit ",
            audio: "https://dns4.vippendu.com/download/128k-dknel/Goti-Soda-Batli-Foda.mp3"

        },


        {
          
            Image: "https://a10.gaanacdn.com/images/albums/79/1994379/crop_480x480_1521715092_1994379.jpg",
            title: "Kayu Khav Chho Fruit Lago",
            subtitle: "Vijay Suvada ",
            audio: "https://www.newgujaratisong.in/wp-content/uploads/2021/12/Kayu-Khav-Chho-Fruit-Lago-Bav-Cute-1.mp3"

        },

        {
         
            Image: "https://i.pinimg.com/originals/23/a0/2e/23a02e80613aa9a1eace3c532756282a.jpg",
            title: " Lammiyan Bandookan Wale",
            subtitle: "Rooh,Abraam",
            audio: "https://dns4.vippendu.com/download/128k-dmcmr/Lammiyan-Bandookan-Wale-(Album-Intro).mp3"

        },



        {
           
            Image: "https://c.saavncdn.com/857/Are-You-Lonely-English-2019-20190213200954-500x500.jpg",
            title: " Incomplete",
            subtitle: " Jay Sean",
            category: "english",
            audio: "https://pagalnew.com/mp3-songs/english-mp3-songs/incomplete-jay-sean-128-kbps-sound.mp3"


        },

        {
          
            Image: "https://static.toiimg.com/photo/msid-78309889/78309889.jpg?223535",
            title: "Fire Honge",
            subtitle: "Dilshan, Indeep Bakshi",
            audio: "https://cdnsongs.com/music/data/Single_Track/202010/Fire_Honge/128/Fire_Honge_1.mp3"

        },

        {
            
            Image: "https://images-na.ssl-images-amazon.com/images/I/51mw+YyKTRL._SX322_BO1,204,203,200_.jpg",
            title: "Garda",
            subtitle: "Daler Mehndi",
            audio: "https://pagalfree.com/musics/128-Garda%20-%20Atrangi%20Re%20128%20Kbps.mp3"

        },


        {
           
            Image: "https://upload.wikimedia.org/wikipedia/en/thumb/d/dc/Bollywood-Hollywood%2C_movie_poster%2C_2002.jpg/220px-Bollywood-Hollywood%2C_movie_poster%2C_2002.jpg",
            title: "Pyaar Karte Ho Na",
            subtitle: "Javed-Mohsin, Stebin Ben,",
            audio: "https://pagalfree.com/musics/128-Pyaar%20Karte%20Ho%20Na%20-%20Stebin%20Ben%20128%20Kbps.mp3"

        },

        {
          
            Image: "https://1.bp.blogspot.com/-IPquRofuKdc/XiVyjnvswjI/AAAAAAAAQFw/VW_h_ZQ9P5cvEMfe_dnJDzKCrE1Uyk1ewCLcBGAsYHQ/s1600/shubh-mangal-zyada-saavdhan-movie-star-cast-release-date-poster.jpg",
            title: "100 Vichon 100",
            subtitle: "Jenny Johal, R Nait, Laddi",
            audio: "https://pagalfree.com/musics/128-100%20Vichon%20100%20-%20R%20Nait%20128%20Kbps.mp3"

        },


        {
           
            Image: "https://odishabytes.com/wp-content/uploads/2017/06/bb-song-1.jpg",
            title: "Chalke Re",
            subtitle: "A.R. Rahman, Aditi Paul, Srinivas",
            audio: "https://pagalfree.com/musics/128-Chalke%20Re%20-%20Lingaa%20(Hindi)%20128%20Kbps.mp3"

        },

    ]


}