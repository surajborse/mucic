import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './Component/Header';
import Home from './Component/Home';
import MusicTab from './Component/MusicTab';
import AudioList from './Component/AudioList';
import { useState } from 'react';
import Footer from './Component/Footer';

function App() {

  const [list, setList] = useState(false)

  const backbnt = () => {
    setList(false)
  }

  return (
    <div className="App">
      <div className="music-app">
        <Header />
        <Home />
        <MusicTab />
        {
          list && <AudioList backbnt={backbnt} />
        }
        <button onClick={() => setList(true)} className="all-music" > All Music </button>
        <Footer />
      </div>
    </div>
  );
}

export default App;
