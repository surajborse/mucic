import React from 'react'
import { CgSearch } from 'react-icons/cg'
import { HiOutlineChevronLeft } from "react-icons/hi"
import { Music } from '../AllData'


function AudioList({ backbnt }) {
    return (

        <div className='audiolist'>
            
            <div className="header">
                <div className="pre-btn " onClick={backbnt}>
                    <HiOutlineChevronLeft />
                </div>
                <div className="search">
                    <CgSearch />
                </div>
            </div>

            <div>
                {
                    Music.map((e, index) => {
                        return (
                            <div className="list" key={index}>
                                <div className="music-img">
                                    <img src={e.Image} className='img-fluid' alt="" />
                                </div>
                                <div className=" ms-3 music-content">
                                    <p> {e.title} </p>
                                    <p> {e.subtitle} </p>
                                </div>
                            </div>
                        )
                    })
                }


                {/* <div className="list">
                    <div className="music-img">
                        <img src="https://cdn.pixabay.com/audio/2022/06/27/12-00-45-604_200x200.jpg" className='img-fluid' alt="" />
                    </div>
                    <div className=" ms-3 music-content">
                        <p>Beyond the Line</p>
                        <p> Riwan khan </p>
                    </div>
                </div>

                <div className="list">
                    <div className="music-img">
                        <img src="https://pagalworld.com.se/siteuploads/thumb/sft7/3198_4.jpg" className='img-fluid' alt="" />
                    </div>
                    <div className=" ms-3 music-content">
                        <p>Beyond the Line</p>
                        <p> Riwan khan </p>
                    </div>
                </div> */}

            </div>


        </div>
    )
}

export default AudioList