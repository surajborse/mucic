import React, { useEffect, useRef, useState } from 'react'
import { BsChevronDoubleUp } from "react-icons/bs"
import { AiOutlineHome, AiOutlinePause } from "react-icons/ai"
import { CgProfile } from "react-icons/cg"
import { MdPlayArrow } from "react-icons/md"
import { IoMdClose, } from "react-icons/io"
import { TbPlayerSkipBack, TbPlayerSkipForward } from "react-icons/tb"
import { Music } from '../AllData'
function Footer() {

    const [slideup, setSlideup] = useState(false)


    
    const [play, setPlay] = useState(false)
    
    // const [data, setData] = useState(Music)
    // const [currentsong, setCurrentsong] = useState(Music[0])


    // const audioElem = useRef()

    // useEffect(() => {
    //     if (play) {
    //         audioElem.current.play()
    //     } else {
    //         audioElem.current.push()
    //     }

    // }, [play])



    return (
        <div className={slideup ? "active fix-footer" : " fix-footer "}>

            <div className="top text-center" onClick={() => setSlideup(!slideup)}  >
                <BsChevronDoubleUp />
            </div>

            {
                !slideup &&
                <>
                    <div className=''>
                        <div className="list justify-content-between">
                            <div className='d-flex'>
                                <div className="music-img">
                                    <img src="https://pagalworld.com.se/siteuploads/thumb/sft7/3198_4.jpg" className='img-fluid' alt="" />
                                </div>
                                <div className=" ms-3 music-content">
                                    <p>Beyond the Line</p>
                                    <p> Riwan khan </p>
                                </div>
                            </div>
                            <div className='d-flex me-2'>
                                <div className='play-btn me-2' onClick={() => setPlay(!play)}>
                                    {
                                        play ? <AiOutlinePause /> : <MdPlayArrow />
                                    }

                                </div>

                                <div className='play-btn'>
                                    <IoMdClose />
                                </div>
                            </div>

                        </div>
                    </div>

                    <div className="menu">
                        <div className="home">
                            <AiOutlineHome /><br />
                            <p>Home</p>
                        </div>
                        <div className="home">
                            <CgProfile /> <br />
                            <p>pofile</p>
                        </div>
                    </div>
                </>
            }





            {
                slideup &&


                <div className='main-play'>

                    <div className="play-box">
                        <img src="https://pagalworld.com.se/siteuploads/thumb/sft7/3198_4.jpg" className='img-fluid' alt="" />
                    </div>

                    <h3>Beyond the Line</h3>
                    <h5>Riwan khan </h5>

                    <div className="range">
                        <input type="range" name="" id="" />
                    </div>

                    <div className="navigate-music">
                        <TbPlayerSkipBack />
                        <div className='audio-play' onClick={() => setPlay(!play)} >
                            {
                                play ? <AiOutlinePause /> : <MdPlayArrow />
                            }
                        </div>
                        <TbPlayerSkipForward />
                    </div>

                </div>
            }




        </div >
    )
}

export default Footer