import React, { useState } from 'react'

function MusicTab() {

    const [btnactive, setbtnactive] = useState(1)

    return (
        <div>
            <div className="tab-box">
                <button onClick={() => setbtnactive(1)} className={btnactive === 1 ? "active " : ""} > Commercial </button>
                <button onClick={() => setbtnactive(2)} className={btnactive === 2 ? "active" : ""} > Free License </button>
            </div>

            <div className={`${btnactive === 1 ? 'list-one ' : "list-one  music-tab   "}    `}>
                <div className="music-img">
                    <img src="https://cdn.pixabay.com/audio/2022/06/27/12-00-45-604_200x200.jpg" alt="" className='img-fluid' />
                </div>
                <div className="music-img">
                    <img src="https://pagalworld.com.se/siteuploads/thumb/sft7/3198_4.jpg" className='img-fluid' alt="" />
                </div>

            </div>


            <div className={`${btnactive === 2 ? 'list-one d-block ' : "list-one  music-tab   "}    `}>
                <div>
                    <div>
                        <div className="list">
                            <div className="music-img">
                                <img src="https://pagalworld.com.se/siteuploads/thumb/sft7/3198_4.jpg" className='img-fluid' alt="" />
                            </div>
                            <div className=" ms-3 music-content">
                                <p>Beyond the Line</p>
                                <p> Riwan khan </p>
                            </div>
                        </div>

                        <div className="list">
                            <div className="music-img">
                                <img src="https://cdn.pixabay.com/audio/2022/06/27/12-00-45-604_200x200.jpg" className='img-fluid' alt="" />
                            </div>
                            <div className=" ms-3 music-content">
                                <p>Beyond the Line</p>
                                <p> Riwan khan </p>
                            </div>
                        </div>

                        <audio controls className='op-0'>
                            <source src="https://2022.dming2022.xyz/bollywood%20mp3/Shershaah%20(2021)/01%20-%20Raataan%20Lambiyan%20(128%20Kbps).mp3" type="audio/mpeg" />
                        </audio>

                    </div>
                </div>
            </div>

        </div>
    )
}

export default MusicTab